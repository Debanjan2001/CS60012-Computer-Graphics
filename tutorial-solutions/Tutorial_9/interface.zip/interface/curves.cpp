#include "curves.h"

#ifdef __APPLE__
#include <GLUT/glut.h>
#else
#include <GL/glut.h>
#endif
// #include <GL/glut.h>

#include <cmath>
#include <cassert>
#include <iostream>


Vector2D curveOperations::evaluateBezier(float t) const
{
    assert(t >= 0.0f && t <= 1.0f);
    assert(controlPoints.size() > 1);

    // Evaluate the Bezier curve at the given t parameter.
    // You may find the following functions useful:
    //  - curveOperations::binomialCoefficient(m,i) computes "m choose i", 
    //      aka: (m over i)
    //  - std::pow(t,i) computes t raised to the power i

    //@@@@@@@@@@
    // YOUR CODE HERE
	
	return Vector2D(0.5, 0.5); // REPLACE THIS (used only to compile the code)

    //@@@@@@@@@@
}

void curveOperations::drawBezier() const
{
    // Draw this Bezier curve.
    // Do this by evaluating the curve at some finite number of t-values,
    // and drawing line segments between those points.
    // You may use the curveOperations::drawLine() function to do the actual
    // drawing of line segments.

    //@@@@@@@@@@
    // YOUR CODE HERE

	

    //@@@@@@@@@@
 
}


void curveOperations::drawControlPolygon() const
{
    for (size_t i = 1; i < controlPoints.size(); ++i)
    {
        drawLine(controlPoints[i-1], controlPoints[i]);
    }
}


unsigned long curveOperations::binomialCoefficient(int n, int k)
{
    // Compute nCk ("n choose k")
    // WARNING: Vulnerable to overflow when n is very large!

    assert(k >= 0);
    assert(n >= k);

    unsigned long result = 1;
    for (int i = 1; i <= k; ++i)
    {
        result *= n-(k-i);
        result /= i;
    }
    return result;
}


void curveOperations::drawLine(const Vector2D& p1, const Vector2D& p2)
{
    glBegin(GL_LINES);
    glVertex2f(p1[0], p1[1]);
    glVertex2f(p2[0], p2[1]);
    glEnd();
}



// draw cubic bspline
void curveOperations::drawCubicBspline() const
{
	//@@@@@@@@@@
    // YOUR CODE HERE
	


	//@@@@@@@@@@
}


// draw betaspline
void curveOperations::drawBetaspline() const
{
	//@@@@@@@@@@
    // YOUR CODE HERE
	


	//@@@@@@@@@@
}



/*************************** You don't need to modify this block ***************************/
void CurveManager::drawCurves() const
{
    if (points == NULL || points->size() < 2)
    {
        return;
    }

    if (curveMode == BEZIER_MODE)
    {
        // Basic Mode (default)
        // Create a Bezier curve from the entire set of points,
        // and then simply draw it to the screen.
        
        curveOperations curve(*points);
        curve.drawBezier();

    }
	else
		if (curveMode == CUBIC_BSPLINE_MODE)
		{
			// mode to draw a cubic b-spline
			curveOperations curve(*points);
			curve.drawCubicBspline();
		}
		else
			if (curveMode == BETA_SPLINE_MODE)
			{
				// mode to draw a beta-spline
				curveOperations curve(*points);
				curve.drawBetaspline();
			}
}
/*************************** You don't need to modify this block ***************************/


